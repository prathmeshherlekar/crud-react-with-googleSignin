// import { Row, Col, Button, Table, Container, } from "react-bootstrap";
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css'
import React from 'react';
import Header from "./header";

export default function MainApp() {
    return (
        <>
            {/* <Header /> */}
            <h2>Author</h2>
            <div className="row">
                <div className="col-md-6 offset-3">
                    <table className="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">First</th>
                                <th scope="col">Last</th>
                                <th scope="col">Handle</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>Mark</td>
                                <td>Otto</td>
                                <td>@mdo</td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </>
    )
}
