import { Button,Container,Row,Col } from "react-bootstrap";
// import LoginForm from "./components/LoginForm";
import MainApp from './components/MainApp';
import { useState,useEffect } from "react";
import Header from "./components/header";
function App() {
  const [IsLoggedIn, setIsLoggedIn] = useState(false);
  
  // localStorage.setItem('LogInData',"");
  return (
    <>
    <Header IsLoggedIn={IsLoggedIn} setIsLoggedIn={setIsLoggedIn}/>
    <Container fluid>
     {localStorage.getItem('IsLoggedIn')==='true'?<MainApp/>:"LogIn Please"}
    </Container>
    </>
  );
}

export default App;

